import { Component } from '@angular/core';

@Component({
  selector: 'app-loggedinfooter',
  standalone: true,
  imports: [],
  templateUrl: './loggedinfooter.component.html',
  styleUrl: './loggedinfooter.component.css'
})
export class LoggedinfooterComponent {

}
