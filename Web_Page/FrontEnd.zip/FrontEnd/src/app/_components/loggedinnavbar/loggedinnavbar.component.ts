import { Component } from '@angular/core';

@Component({
  selector: 'app-loggedinnavbar',
  standalone: true,
  imports: [],
  templateUrl: './loggedinnavbar.component.html',
  styleUrl: './loggedinnavbar.component.css'
})
export class LoggedinnavbarComponent {

}
