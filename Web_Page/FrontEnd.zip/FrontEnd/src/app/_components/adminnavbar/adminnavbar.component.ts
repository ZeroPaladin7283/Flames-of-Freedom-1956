import { Component } from '@angular/core';

@Component({
  selector: 'app-adminnavbar',
  standalone: true,
  imports: [],
  templateUrl: './adminnavbar.component.html',
  styleUrl: './adminnavbar.component.css'
})
export class AdminnavbarComponent {

}
